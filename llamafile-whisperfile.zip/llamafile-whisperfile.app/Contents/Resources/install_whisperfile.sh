#!/bin/bash

# Get the path to the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Path to the audio file (e.g., raven_poe_64kb.mp3)
AUDIO_FILE_PATH="$SCRIPT_DIR/raven_poe_64kb.mp3"

# Path to the .llamafile inside the Resources folder
LLAMAFILE_PATH="$SCRIPT_DIR/whisper-tiny.en.llamafile"

# Make sure the .llamafile is executable
chmod +x "$LLAMAFILE_PATH"

# Run the .llamafile
"$LLAMAFILE_PATH" &

# Wait for a moment to ensure the whisper-tiny.en.llamafile has time to start
sleep 5

# Open the user's default browser to localhost:8080
open "http://127.0.0.1:8080/"
